package com.example.SpringMVCViewSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcViewSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
