package com.example.PathVariableSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PathVariableSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
