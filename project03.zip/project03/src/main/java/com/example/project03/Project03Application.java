package com.example.project03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project03Application {

	public static void main(String[] args) {
		SpringApplication.run(Project03Application.class, args);
	}

}
