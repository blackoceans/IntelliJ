package com.example.SpringDataJDBCSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJdbcSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
