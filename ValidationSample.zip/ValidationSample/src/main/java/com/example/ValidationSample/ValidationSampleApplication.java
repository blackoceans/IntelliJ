package com.example.ValidationSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationSampleApplication.class, args);
	}

}
