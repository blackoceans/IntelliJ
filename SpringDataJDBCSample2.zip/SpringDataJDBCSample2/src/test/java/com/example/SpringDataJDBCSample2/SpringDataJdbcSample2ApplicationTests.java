package com.example.SpringDataJDBCSample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJdbcSample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
